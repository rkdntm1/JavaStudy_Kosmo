package shootingGame.model;

public class Target extends Thing {	
	public Target(double x) {
		// 땅에 붙여놓자
		super(x, 0);
	}
}

