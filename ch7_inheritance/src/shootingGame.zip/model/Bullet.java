package shootingGame.model;

public class Bullet extends Thing {
	//각도 속도
	/** m/sec 수평 속도 및 수직 속도*/
	private double xSpeed, ySpeed;
	
	public Bullet() {
		
	}
}

