package shootingGame.model;

public class Target extends Thing {

	public Target(double x) {
		super(x, 0); // target 생성시 x좌표를 받아 그걸 부모 클래스로
	}

}
